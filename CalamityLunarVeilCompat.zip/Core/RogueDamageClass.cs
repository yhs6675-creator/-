// File: Core/RogueCache.cs
using Terraria;
using Terraria.ModLoader;

namespace CalamityLunarVeilCompat {
    internal static class RogueCache {
        private static bool _checked;
        private static bool _calamityPresent;
        private static DamageClass _rogue; // CalamityMod.DamageClasses.RogueDamageClass

        public static bool CalamityPresent {
            get { if (!_checked) Check(); return _calamityPresent; }
        }

        public static DamageClass Rogue {
            get { if (!_checked) Check(); return _rogue ?? DamageClass.Generic; }
        }

        private static void Check() {
            _checked = true;
            _calamityPresent = ModContent.TryFind("CalamityMod/RogueDamageClass", out _rogue);
        }

        public static bool IsRogue(Item item) =>
            CalamityPresent && item?.DamageType == _rogue;
    }
}
